﻿using System;

namespace тима
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Console.WriteLine("Hello Tima");
            //            Console.WriteLine("Hello Anton");
            //}

            //for (int i = 0; i < 20; i++)
            //{
            //    Console.Write('.');
            //}
            ////for (int i = 0; i < 20; i++)
            ////{
            ////    Console.SetCursorPosition(20, i);
            ////    Console.Write('.');
            ////}

            ////for (int i = 20; i >= 0; i=i - 2)

            ////{
            ////    Console.SetCursorPosition(i, 20);
            ////    Console.Write('.');
            ////}

            ////for (int i = 20; i >= 0; --i)

            ////{
            ////    Console.SetCursorPosition(0, i);
            ////    Console.Write('.');
            ////}


            ////int r = 5;
            ////int x = 0;
            ////int k = 3;
            ////for (int y = 0; y < r; ++y)
            ////{
            ////    x = (int)Math.Round(k * Math.Sqrt((Math.Pow(r, 2) - Math.Pow(y, 2))));
            ////    Console.SetCursorPosition(x + r, y + r); 
            ////    Console.Write('o');
            ////    Console.SetCursorPosition(x + r, -y + r);
            ////    Console.Write('o');
            ////    Console.SetCursorPosition(-x + k * r, -y + r);
            ////    Console.Write('o');
            ////    Console.SetCursorPosition(-x + k * r, y + r);
            ////    Console.Write('o');

            ////}


            ////string strS = "+---+\n    |\n ___| \n|\n|  \n+---+\n";
            ////Console.WriteLine(strS);
            ////Console.WriteLine();


            ////string strT = "+---+\n  | \n  |\n  | \n  |";
            //////Console.WriteLine(strT);
            //////Console.WriteLine();


            ////string strE = "+---+\n|\n+---+\n|\n+---+\n   ";
            ////Console.WriteLine(strE);
            ////Console.WriteLine();


            //////string strM = "+    +\n++  ++\n+ ++ +\n+    +\n+    +";
            //////Console.WriteLine(strM);
            //////Console.WriteLine();


            ////string strL = "|\n|\n|\n|_____";
            ////Console.WriteLine(strL);
            ////Console.WriteLine();


            ////string strA = "     +\n    +  +\n   +____+\n  +      +\n +        +";
            ////Console.WriteLine(strA);
            ////Console.WriteLine();


            ////string strB = "|______\n|      |\n|______|\n|      |\n|______|";
            ////Console.WriteLine(strB);
            ////Console.WriteLine();



            ////Console.WriteLine(strT);
            ////Console.WriteLine();


            ////string strI = "+\n|\n|\n|\n|";
            ////Console.WriteLine(strI);
            ////Console.WriteLine();


            ////string strM = "+    +\n++  ++\n+ ++ +\n+    +\n+    +";
            ////Console.WriteLine(strM);
            ////Console.WriteLine();


            ////string strA = "     +\n    +  +\n   +____+\n  +      +\n +        +";
            ////Console.WriteLine(strA);
            ////Console.WriteLine();



            ////string strSERD = "          ++   ++\n         +   ++  +\n        +         + \n       +           +\n      +             + \n       +           +\n        +         +\n         +       +\n          +     +\n           +   +\n            + +\n             +";
            ////Console.WriteLine(strSERD);
            ////Console.WriteLine();


            ////string strS = "+---+\n    |\n ___| \n|\n|  \n+---+\n";
            ////Console.WriteLine(strS);
            ////Console.WriteLine();


            ////string strA = "     +\n    +  +\n   +____+\n  +      +\n +        +";
            ////Console.WriteLine(strA);
            ////Console.WriteLine();


            ////string strF = "+---+\n|\n|\n|+---+\n|\n|";
            ////Console.WriteLine(strF);
            ////Console.WriteLine();


            ////string strE = "+---+\n|\n+---+\n|\n+---+\n   ";
            ////Console.WriteLine(strE);
            ////Console.WriteLine();


            ////string strT = "+---+\n  | \n  |\n  | \n  |";
            ////Console.WriteLine(strT);
            ////Console.WriteLine();


            ////string strY = "+     +\n  +  +\n    +\n    +\n    +\n    +";
            ////Console.WriteLine(strY);
            ////Console.WriteLine();


            ////string strC = "____\n|\n|\n|\n|\n|____";
            ////Console.WriteLine(strC);
            ////Console.WriteLine();


            ////string strsharp = "__|__|__\n  |  |\n__|__|__\n  |  | ";
            ////Console.WriteLine(strsharp);
            ////Console.WriteLine();


            ////string strTR = "     +\n    +  +\n   +    +\n  +      +\n +        +\n++++++++++++";
            ////Console.WriteLine(strTR);
            //// //Console.WriteLine();


            ////string strCUBE = "+          +\n+          +\n+          +\n+          +\n++++++++++++";
            ////Console.WriteLine(strCUBE);
            //////Console.WriteLine();


            //int r = 2;
            //int x = 0;
            //int k = 3
            //;
            //for (int y = 0; y < r; ++y)
            //{
            //    x = (int)Math.Round(k * Math.Sqrt((Math.Pow(r, 2) - Math.Pow(y, 2))));
            //    Console.SetCursorPosition(1+x + r, 5+y + r);
            //    Console.Write('o');
            //    Console.SetCursorPosition(1+x + r, 5-y + r);
            //    Console.Write('o');
            //    Console.SetCursorPosition(1-x + k * r, 5-y + r);
            //    Console.Write('o');
            //    Console.SetCursorPosition(1-x + k * r,5+y + r);
            //    Console.Write('o');

            //}



            //string strA = "     +\n    +  +\n   +____+\n  +      +\n +        +";
            //Console.WriteLine(strA);
            //Console.WriteLine();


            //string strB = "|______\n|      |\n|______|\n|      |\n|______|";
            //Console.WriteLine(strB);
            //Console.WriteLine();


            //string strC = "____\n|\n|\n|\n|\n|____";
            //Console.WriteLine(strC);
            //Console.WriteLine();


            //string strD = "|______\n|      |\n|      |\n|      |\n|______|\n|";
            //Console.WriteLine(strD);
            //Console.WriteLine();


            //string strE = "+---+\n|\n+---+\n|\n+---+\n   ";
            //Console.WriteLine(strE);
            //Console.WriteLine();



            //string strF = "+---+\n|\n|\n|+---+\n|\n|";
            //Console.WriteLine(strF);
            //Console.WriteLine();



            //string strG = "|_____\n|     |\n|  ___\n|     |\n|_____|";
            //Console.WriteLine(strG);
            //Console.WriteLine();



            //string strH = "|     |\n|_____|\n|     |\n|     |";
            //Console.WriteLine(strH);
            //Console.WriteLine();


            //string strI = "+\n|\n|\n|\n|";
            //Console.WriteLine(strI);
            //Console.WriteLine();


            //string strJ = "   |\n   |\n   |\n|__|";
            //Console.WriteLine(strJ);
            //Console.WriteLine();


            //string strK = "|  /    \n| /     \n|/   \n|    \n|";
            //Console.WriteLine(strK);
            //Console.WriteLine();

            //Console.WriteLine("таблица сложения");
            //for (int i = 15; i > 0; --i)

            //{
            //        for (int j = 15; j > 0; j--)

            //    { 
            //    Console.Write($"{i * j,-3} ");

            //    }
            //    Console.WriteLine();
            //    Console.WriteLine();

            //}


            int value = 0;
            int num = 0;
            string input_string = "";
            int i = 0;
            bool run = true;

            Console.WriteLine("<<<угадай число>>>");
            Console.WriteLine("я загадал число от 0 до 20 - а ты угадай!");

            while (run)
            {

                Random rnd = new Random();
                value = rnd.Next(0, 20);
                Console.WriteLine("Твой ход ");
                Console.WriteLine("Напиши число:");



                for (i = 0; i < 10 && num != value; i++)
                {
                    Console.WriteLine("ход #" + i);
                    input_string = Console.ReadLine();
                    num = Int32.Parse(input_string);

                    if (num != value)
                    {
                        Console.WriteLine("неправильно");
                        if (num > value)
                        {
                            Console.WriteLine("меньше");
                        }
                        else
                        {
                            Console.WriteLine("больше");
                        }

                    }
                }
                if (num == value)
                {
                    Console.WriteLine("победа");
                }
                else
                {
                    Console.WriteLine("проигрыш");
                }
                Console.WriteLine("хочешь поиграть ешё? нажми y/n");
                while (input_string != "y" & input_string != "n")
                {
                    input_string = Console.ReadLine();
                    if (input_string == "y")
                    { }
                    else
                    {
                        if (input_string == "n")
                        {
                            run = false;
                        }
                        else
                        {
                            Console.WriteLine("не понял, введите ответ");
                        }
                    }
                }


                //string name = "Tima";
                //int age = 12;
                //bool isEmployed = false;
                //double weight = 41;
                //bool playpcgames = true;
                //string school = "N56 города Минска";
                //int HMPC =  12;
                //double pieceofpizza = 0.25;

                //Console.WriteLine($"имя: {name}");
                //Console.WriteLine($"возраст: {age}");
                //Console.WriteLine($"вес: {weight}");
                //Console.WriteLine($"работает: {isEmployed}");
                //Console.WriteLine($"играю ли я в компьютерные игры: {playpcgames}");
                //Console.WriteLine($"школа: {school}");
                //Console.WriteLine($"сколько компьютеров в класе в школе: {HMPC}");
                //Console.WriteLine($"какая часть пиццы достанется, если ее делят на 4 человека?: {pieceofpizza}");

                //Console.Write("Введите имя : ");
                //string name = Console.ReadLine();

                //Console.Write("Введите возраст: ");
                //int age = Convert.ToInt32(Console.ReadLine());

                //Console.Write("Введите рост: ");
                //double height = Convert.ToDouble(Console.ReadLine());

                //Console.Write("Введите введите размер зарплаты: ");
                //decimal salary = Convert.ToDecimal(Console.ReadLine());

                //Console.Write("Введите отчество: ");
                //string surname = Console.ReadLine();

                //Console.Write("Введите количество этажей в школе: ");
                //int HMFIS = Convert.ToInt32(Console.ReadLine());

                //Console.Write("Введите  какая часть торта получится если делить торт на пятерых человек : ");
                //double HMPOC = Convert.ToDouble(Console.ReadLine());

                //long number = +375259227396;
                ////   Console.WriteLine($"{number: +### ## ### ## ##}");

                //Console.Write("сколько будет 5 * 20  "  );
                //int cto = Convert.ToInt32(Console.ReadLine());

                //int protvet = 100;

                //if (cto != protvet)
                //{
                //    Console.WriteLine("неправильно");
                //}
                //else
                //{
                //    Console.WriteLine("правильно");
                //}
                //Console.WriteLine($"Имя: {name}, возраст: {age}, рост: {height}, зарплата: {salary}$, отчество: {surname}, этажи в школе: {HMFIS}, 1 часть торта на 5 человек: {HMPOC}, номер: {number: +### ## ### ## ##} 5 * 20 = {сто} ");









                //Console.Write($"{i * j,-3} ");


                Console.ReadLine();

            }
        }
    }
}

    



